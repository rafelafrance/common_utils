# common_utils ![CI](https://github.com/rafelafrance/common_utils/workflows/CI/badge.svg)
Utilities used in several repositories
